lambda_handler(context, event):
    exit 0
